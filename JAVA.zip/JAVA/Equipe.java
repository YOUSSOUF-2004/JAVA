
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Equipe {

	/**
	 * Default constructor
	 */
	public Equipe() {
	}

	/**
	 * 
	 */
	public void id_equipe;

	/**
	 * 
	 */
	public void nom_equipe;

	/**
	 * 
	 */
	public void membres;

	/**
	 * 
	 */
	public void projets;

	/**
	 * 
	 */
	public void Ajouter_Membre() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void Supprimer_Membre() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void Afficher_Membre() {
		// TODO implement here
	}

}