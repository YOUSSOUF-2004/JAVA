
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Rapport test extends Produit {

	/**
	 * Default constructor
	 */
	public Rapport test() {
	}

	/**
	 * 
	 */
	public void id_rapportt;

	/**
	 * 
	 */
	public void resultats;

	/**
	 * 
	 */
	public void statut;

	/**
	 * 
	 */
	public void ajouterResultat() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficherRapport() {
		// TODO implement here
	}

}