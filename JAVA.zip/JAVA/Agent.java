
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Agent extends Resource {

	/**
	 * Default constructor
	 */
	public Agent() {
	}

	/**
	 * 
	 */
	public void Mat_Ag;

	/**
	 * 
	 */
	public void Nom_Ag;

	/**
	 * 
	 */
	public void Prenom_Ag;

	/**
	 * 
	 */
	public void Date_Nai_Ag;

	/**
	 * 
	 */
	public void AssignerTache() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficherDetails() {
		// TODO implement here
	}

}