
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Date {

	/**
	 * Default constructor
	 */
	public Date() {
	}

	/**
	 * 
	 */
	public void Date_Affecter;

	/**
	 * 
	 */
	public void jour;

	/**
	 * 
	 */
	public void mois;

	/**
	 * 
	 */
	public void Annee;

	/**
	 * 
	 */
	public void AfficherDate() {
		// TODO implement here
	}

	/**
	 * @param Date
	 */
	public void calculerDifference(void Date) {
		// TODO implement here
	}

}