
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Reuinion {

	/**
	 * Default constructor
	 */
	public Reuinion() {
	}

	/**
	 * 
	 */
	public void id_reunion;

	/**
	 * 
	 */
	public void date;

	/**
	 * 
	 */
	public void heure;

	/**
	 * 
	 */
	public void sujet;

	/**
	 * 
	 */
	public void organiser() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher_details() {
		// TODO implement here
	}

}