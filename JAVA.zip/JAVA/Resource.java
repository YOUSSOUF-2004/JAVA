
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Resource {

	/**
	 * Default constructor
	 */
	public Resource() {
	}

	/**
	 * 
	 */
	public void id_resource;

	/**
	 * 
	 */
	public void nom;

	/**
	 * 
	 */
	public void type;

	/**
	 * @param projet
	 */
	public void allouer_projet(void projet) {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher_disponiblite() {
		// TODO implement here
	}

}