
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Tache {

	/**
	 * Default constructor
	 */
	public Tache() {
	}

	/**
	 * 
	 */
	public void id_tache;

	/**
	 * 
	 */
	public void nom_tache;

	/**
	 * 
	 */
	public void Des;

	/**
	 * 
	 */
	public void Date_revenu;

	/**
	 * 
	 */
	public void Date_Effective;

	/**
	 * 
	 */
	public void Date_Tremine;

	/**
	 * @param membre
	 */
	public void assigner_a_membre(void membre) {
		// TODO implement here
	}

	/**
	 * @param statut
	 */
	public void changer_statut(void statut) {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher_details() {
		// TODO implement here
	}

}