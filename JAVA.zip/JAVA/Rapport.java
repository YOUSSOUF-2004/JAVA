
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Rapport {

	/**
	 * Default constructor
	 */
	public Rapport() {
	}

	/**
	 * 
	 */
	public void id_rapport;

	/**
	 * 
	 */
	public void titre;

	/**
	 * 
	 */
	public void Taux de realialisation;

	/**
	 * 
	 */
	public void Type_Support;

	/**
	 * 
	 */
	public void date_creation;

	/**
	 * 
	 */
	public void generer() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher() {
		// TODO implement here
	}

}