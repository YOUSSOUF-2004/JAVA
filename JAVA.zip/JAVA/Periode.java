
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Periode {

	/**
	 * Default constructor
	 */
	public Periode() {
	}

	/**
	 * 
	 */
	public void date_debut;

	/**
	 * 
	 */
	public void date_fin;

	/**
	 * 
	 */
	public void calculerDuree() {
		// TODO implement here
	}

	/**
	 * @param Date_debut Date_Fin
	 */
	public void modifier_periode(void Date_debut Date_Fin) {
		// TODO implement here
	}

}