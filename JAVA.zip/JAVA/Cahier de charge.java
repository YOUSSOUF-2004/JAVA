
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Cahier de charge extends Produit {

	/**
	 * Default constructor
	 */
	public Cahier de charge() {
	}

	/**
	 * 
	 */
	public void titre;

	/**
	 * 
	 */
	public void desc;

	/**
	 * 
	 */
	public void date_creation;

	/**
	 * 
	 */
	public void Ajouter_Exigence() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void Afficher_cahier_de_charge() {
		// TODO implement here
	}

}