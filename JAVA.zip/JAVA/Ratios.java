
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Ratios {

	/**
	 * Default constructor
	 */
	public Ratios() {
	}

}