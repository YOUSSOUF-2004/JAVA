
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Rendement {

	/**
	 * Default constructor
	 */
	public Rendement() {
	}

	/**
	 * 
	 */
	public void equipe;

	/**
	 * 
	 */
	public void source;

	/**
	 * 
	 */
	public void Calculer_rendement() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher_rendement() {
		// TODO implement here
	}

}