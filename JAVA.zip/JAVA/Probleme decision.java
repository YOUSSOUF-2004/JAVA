
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Probleme decision {

	/**
	 * Default constructor
	 */
	public Probleme decision() {
	}

	/**
	 * 
	 */
	public void id;

	/**
	 * 
	 */
	public void descroption;

	/**
	 * 
	 */
	public void solution;

	/**
	 * 
	 */
	public void ajouter_solution() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher_probleme() {
		// TODO implement here
	}

}