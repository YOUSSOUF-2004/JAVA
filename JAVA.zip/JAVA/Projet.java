
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Projet {

	/**
	 * Default constructor
	 */
	public Projet() {
	}

	/**
	 * 
	 */
	public void id_projet;

	/**
	 * 
	 */
	public void nom_projet;

	/**
	 * 
	 */
	public void des;

	/**
	 * 
	 */
	public void date_debut;

	/**
	 * 
	 */
	public void date_fin;

	/**
	 * 
	 */
	public void statut;

	/**
	 * 
	 */
	public void creer_projet() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void modifier_projet() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher_projet() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void cloture_projet() {
		// TODO implement here
	}

}