
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Document Conception extends Produit {

	/**
	 * Default constructor
	 */
	public Document Conception() {
	}

	/**
	 * 
	 */
	public void titre;

	/**
	 * 
	 */
	public void contenu;

	/**
	 * 
	 */
	public void version;

	/**
	 * 
	 */
	public void ModifierDocumement() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void nouveauContenu() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficherDocument() {
		// TODO implement here
	}

}