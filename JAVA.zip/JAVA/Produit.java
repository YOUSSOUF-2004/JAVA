
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Produit {

	/**
	 * Default constructor
	 */
	public Produit() {
	}

	/**
	 * 
	 */
	public void id_produit;

	/**
	 * 
	 */
	public void nom;

	/**
	 * 
	 */
	public void des;

	/**
	 * 
	 */
	public void type;

	/**
	 * 
	 */
	public void ajouter_produit() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher_produit() {
		// TODO implement here
	}

}