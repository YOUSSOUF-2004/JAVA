
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Outils logiciels extends Resource {

	/**
	 * Default constructor
	 */
	public Outils logiciels() {
	}

	/**
	 * 
	 */
	public void Nom_outols;

	/**
	 * 
	 */
	public void Version;

	/**
	 * 
	 */
	public void Licence;

	/**
	 * @param strignnouvelleVersion
	 */
	public void mettreAjour(void strignnouvelleVersion) {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void verifierLicence() {
		// TODO implement here
	}

}