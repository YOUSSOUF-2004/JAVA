
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Code source extends Produit {

	/**
	 * Default constructor
	 */
	public Code source() {
	}

	/**
	 * 
	 */
	public void Nom_fichier;

	/**
	 * 
	 */
	public void contenu;

	/**
	 * 
	 */
	public void modifier_code() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void afficher_code() {
		// TODO implement here
	}

}