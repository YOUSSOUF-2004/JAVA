
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Outilsmateriels extends Resource {

	/**
	 * Default constructor
	 */
	public Outilsmateriels() {
	}

	/**
	 * 
	 */
	public void Type;

	/**
	 * 
	 */
	public void qua;

	/**
	 * 
	 */
	public void ajouterOutil() {
		// TODO implement here
	}

	/**
	 * 
	 */
	public void supprimerOutil() {
		// TODO implement here
	}

}